import argparse
import os
import typing as _TYPE
from main import generate_totp_token
from pathlib import Path


class NoKeyFoundError(FileNotFoundError):
    def __init__(self, org_name: str):
        self.org_name = org_name
        super().__init__(
            f"No key found for organization '{org_name}'. "
            "Use the 'add' command -a or --add to add a new org key"
        )


def ensure_open2fa_dir() -> str:
    """Ensure the .open2fa directory exists in the user's home directory.
    Returns:
        str: path to the .open2fa directory.
    """
    open2fa_dir = Path.home() / '.open2fa'
    open2fa_dir.mkdir(mode=0o700, exist_ok=True)
    return str(open2fa_dir)


def get_key_files(org_name: str) -> _TYPE.List[str]:
    """
    Get the file path for the secret key of an organization.
    Args:
        org_name (str): The name of the organization.
    Returns:
        Path: Path object to the key file.
    """
    open2fa_dir = ensure_open2fa_dir()
    dirfiles = os.listdir(open2fa_dir)
    orgfiles = [file for file in dirfiles if file.startswith(org_name.lower())]
    if len(orgfiles) == 0:
        raise NoKeyFoundError(org_name)
    return open2fa_dir / f'{org_name}.key'


def add_secret_key(org_name: str, secret: str) -> None:
    """
    Add a new secret key for an organization.
    Args:
        org_name (str): The name of the organization.
        secret (str): The base32 encoded secret key.
    """
    key_file_path = get_key_file_path(org_name)
    with key_file_path.open('w') as key_file:
        key_file.write(secret)
    key_file_path.chmod(0o600)


def get_secret_key(org_name: str) -> Optional[str]:
    """
    Retrieve the secret key for an organization.
    Args:
        org_name (str): The name of the organization.
    Returns:
        Optional[str]: The base32 encoded secret key for the organization, if available.
    """
    key_file_path = get_key_file_path(org_name)
    if key_file_path.is_file():
        return key_file_path.read_text().strip()
    return None


def main() -> None:
    """
    Main function to handle the CLI commands.
    """
    parser = argparse.ArgumentParser(
        description="open2fa CLI: simple 2FA cli interface for open2fa"
    )
    subparsers = parser.add_subparsers(dest='command', required=True)

    parser_add = subparsers.add_parser(
        'add', help='Add a new TOTP secret key for an organization'
    )
    parser_add.add_argument(
        'org_name', type=str, help='Name of the organization'
    )
    parser_add.add_argument('secret', type=str, help='The TOTP secret key')

    # Subparser for the 'generate' command
    parser_generate = subparsers.add_parser(
        'generate', help='Generate a TOTP code for an organization'
    )
    parser_generate.add_argument(
        'org_name', type=str, help='Name of the organization or its prefix'
    )
    parser_generate.add_argument(
        '--fulllength',
        '-f',
        action='store_true',
        help='Match the full length of the organization name',
    )

    args = parser.parse_args()

    if args.command == 'add':
        ensure_open2fa_dir()
        add_secret_key(args.org_name, args.secret)
        print(f"Added secret key for {args.org_name}.")

    elif args.command == 'generate':
        secret = get_secret_key(args.org_name)
        if secret:
            token = generate_totp_token(secret)
            print(f"{args.org_name}: {token}")
        else:
            # Search for organization by prefix if not full length match
            if not args.fulllength:
                open2fa_dir = ensure_open2fa_dir()
                prefix = args.org_name.lower()
                matched_orgs = [
                    org.stem for org in open2fa_dir.glob(f'{prefix}*.key')
                ]
                if len(matched_orgs) == 1:
                    secret = get_secret_key(matched_orgs[0])
                    if secret:
                        token = generate_totp_token(secret)
                        print(f"{matched_orgs[0]}: {token}")
                        return
                elif len(matched_orgs) > 1:
                    print(
                        "Multiple organizations found starting with"
                        f" '{prefix}': {', '.join(matched_orgs)}"
                    )
                    return

            print(f"No key found for organization '{args.org_name}'.")


if __name__ == "__main__":
    main()
