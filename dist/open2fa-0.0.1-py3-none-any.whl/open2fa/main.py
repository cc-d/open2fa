import base64
import hashlib
import hmac
import struct
import time
from typing import Optional
from pathlib import Path


def generate_totp_token(secret: str, interval_length: int = 30) -> str:
    """
    Generate a TOTP token using the provided secret key.
    Args:
        secret (str): The base32 encoded secret key.
        interval_length (int): The time step in seconds. Default is 30 seconds.
    Returns:
        str: A 6-digit TOTP token.
    """
    key = base64.b32decode(secret, casefold=True)
    interval = int(time.time()) // interval_length
    msg = struct.pack(">Q", interval)
    hmac_digest = hmac.new(key, msg, hashlib.sha1).digest()
    o = hmac_digest[19] & 15
    code = struct.unpack(">I", hmac_digest[o : o + 4])[0] & 0x7FFFFFFF
    return str(code % 10**6).zfill(6)
