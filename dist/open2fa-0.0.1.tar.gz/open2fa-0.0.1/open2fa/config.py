from pathlib import Path

OPEN2FA_DIR = Path.home() / '.open2fa'

# octal directory permissions
OPEN2FA_DIR_PERMS = 0o600

# octal file permissions
KEY_FILE_PERMS = 0o600
