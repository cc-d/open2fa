# open2fa
A 100% libre bare-bones python TOTP 2FA client intended mainly to allow me to publish to pypi again, without using a mobile device 2fa scheme
